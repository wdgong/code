from _version import __version_info__, __version__
